<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($coffee['title']); ?></title>
</head>
<body>
<h1><?php echo e($coffee['title']); ?></h1>
<p>Description: <?php echo e($coffee['description']); ?></p>
<img src="<?php echo e($coffee['image']); ?>" alt="coffee img">
</body>
</html>
<?php /**PATH C:\Users\Sterre\PhpstormProjects\test-php-project\example-app\resources\views/coffees/show.blade.php ENDPATH**/ ?>